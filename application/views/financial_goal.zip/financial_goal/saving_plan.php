 
 <div class="pcoded-content">
                     <div class="page-header card">
                        <div class="row align-items-end">
                           <div class="col-lg-8">
                              <div class="page-header-title">
                                 <i class="feather icon-clipboard bg-c-blue"></i>
                                 <div class="d-inline">
                                    <h5>Savings Goals</h5>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4">
                              <div class="page-header-breadcrumb">
                                 <ul class=" breadcrumb breadcrumb-title">
                                    <li class="breadcrumb-item">
                                       <a href="index.html"><i class="feather icon-home"></i></a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="#!">Financial Goals</a></li>
                                    <li class="breadcrumb-item">
                                       <a href="#!">Savings Goals</a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="pcoded-inner-content">
                        <div class="main-body">
                           <div class="page-wrapper">
                              <div class="page-body">
                                 <div class="row">
                                    <div class="col-sm-12">
                                       <div class="card">
                                          <div class="card-header">
                                             <h5>Savings Plan</h5>
                                          </div>
                                          <form method="post" action="<?= site_url('Financial_goal/save_saving_plan') ?>">
                                          <div class="card-block">
                                             <div class="row">
                                                <div class="col-md-6">
                                                   <div class="form-group">
                                                      <label>Saving Goals</label>
                                                      <input type="hidden" name="id" value="<?= $_SESSION['id'] ?>">
                                                      <input type="text" name="saving_goals" placeholder="Saving Goals" class="form-control" style="border-radius: 20px;">
                                                   </div>
                                                </div>
                                                <div class="col-md-6">
                                                   <div class="form-group">
                                                      <label>Periods</label>
                                                      <input type="text" name="peroid" placeholder="Periods" class="form-control" style="border-radius: 20px;">
                                                   </div>
                                                </div>
                                             </div>

                                             <div class="row">

                                               <div class="col-md-6">
                                                   <div class="form-group">
                                                      <label>Period Type</label>
                                                      <select class="form-control" name="period_type"style="border-radius: 20px;border:2px solid black;">
                                                        <option value="">Select Period Type</option>
                                                        <option value="m">Monthly</option>
                                                        <option value="y">Yearly</option>
                                                      </select>
                                                   </div>
                                                </div>


                                                <div class="col-md-6">
                                                   <div class="form-group">
                                                      <label>Per Period Amount To Saved</label>
                                                      <input type="text" name="saved" placeholder="Per Period Amount To Saved" class="form-control" style="border-radius: 20px;">
                                                   </div>
                                                </div>
                                             </div>
                                             <button style="border-radius: 20px;" type="submit" class="btn btn-primary">Save Saving Plan</button>

                                          </div>
                                        </form>
                                       </div>
                                     
                                    </div>
                                    <div class="col-md-12 card">
                                        <table class="table table-borderd">
                                          <thead class="text-center">
                                            <tr>
                                              <th>S No</th>
                                              <th>Saving Goal</th>
                                              <th>Priod</th>
                                              <th>Period Type</th>
                                              <th>Per Period Amount To Save</th>
                                            </tr>
                                          </thead>
                                          <tbody class="text-center">
                                              <?php 
                                              $count = 1;
                                              foreach($record as $rec):?>
                                                  <tr>
                                                    <td><?= $count++ ?></td>
                                                    <td><?= number_format($rec->saving_goal)?></td>
                                                    <td><?= $rec->period?></td>
                                                    <td><?php 
                                                      if ($rec->period_type=="m") 
                                                      {
                                                        echo "Monthly";
                                                      }
                                                      else{
                                                        echo "Yearly";
                                                      }

                                                     ?></td>
                                                      }
                                                    <td><?= number_format($rec->per_period_amount_to_saved)?></td>
                                                  </tr>
                                              <?php endforeach; ?>
                                          </tbody>
                                        </table>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div id="styleSelector"></div>
                        <script>
                          <?php if ($this->session->flashdata('success_msg')):?>
                          $(document).ready(function(){
                            $.toast({
                            heading: 'Success',
                            text: '<?= $this->session->flashdata('success_msg');?>',
                            icon: 'success',
                            loader: true,
                            loaderBg: '#fff',
                            showHideTransition: 'plain',
                            hideAfter: 3000,
                            position: {
                              left: 100,
                              top: 30
                            }
                          })
                          })
<?php endif; ?>
                        </script>
                     </div>
                  </div>