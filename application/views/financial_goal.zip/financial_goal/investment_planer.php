<div class="pcoded-content">
   <div class="page-header card">
      <div class="row align-items-end">
         <div class="col-lg-8">
            <div class="page-header-title">
               <i class="feather icon-clipboard bg-c-blue"></i>
               <div class="d-inline">
                  <h5>Investment Planner</h5>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="page-header-breadcrumb">
               <ul class=" breadcrumb breadcrumb-title">
                  <li class="breadcrumb-item">
                     <a href="index.html"><i class="feather icon-home"></i></a>
                  </li>
                  <li class="breadcrumb-item"><a href="#!">Financial Goals</a></li>
                  <li class="breadcrumb-item">
                     <a href="#!">Finncial</a>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
   <div class="pcoded-inner-content">
      <div class="main-body">
         <div class="page-wrapper">
            <div class="page-body">
               <div class="row">
                  <div class="col-md-12">
                     <form method="post" action="<?= site_url('Financial_goal/save_investment_plan') ?>">
                        <table class="table table-bordered table-hover" id="tab_logic">
                           <thead>
                              <tr>
                                 <th class="text-center"> # </th>
                                 <th class="text-center"> Per Period Contribution </th>
                                 <th class="text-center"> Period </th>
                                 <th class="text-center"> Intrest rate on investment </th>
                                 <th class="text-center"> Value of investment </th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr id='addr0'>
                                 <td>1</td>
                                 <td>
                                    <input type="hidden" name="user_id[]" value="<?= $_SESSION['id'] ?>">
                                    <input type="text" style="border-radius: 20px;" name='contribution[]'  placeholder='Per Period Contribution' class="form-control"/>
                                 </td>
                                 <td><input type="number" style="border-radius: 20px;" name='period[]' placeholder='Period' class="form-control qty" step="0" min="0"/></td>
                                 <td><input type="text" style="border-radius: 20px;" name='intrsest[]' placeholder='Intrest rate on investment' class="form-control price"/></td>
                                 <td><input type="number" style="border-radius: 20px;" name='investment[]' placeholder='Value of investment' class="form-control total"/></td>
                              </tr>
                              <button type="submit" class="btn btn-primary">
                              Save Record
                              <i class="fa fa-save"></i>
                              </button>
                              <tr id='addr1'></tr>
                           </tbody>
                        </table>
                  </div>
                  </form>
                  <div class="row clearfix">
                     <div class="col-md-12" style="margin-right: 25%;">
                        <button id="add_row" type="button" class="btn btn-primary pull-left" style="border-radius:20px;">Add Row
                        <i class="fa fa-plus"></i>
                        </button>
                        <button id='delete_row' type="button" class="pull-right  btn btn-danger" style="border-radius:20px;">
                        <i class="fa fa-trash"></i>
                        Delete Row</button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
           </div>
         <div class="row">
            
             <div class="col-md-12">
               
               <table class="table table-bordered">
                  <thead class="text-center">
                     <tr>
                        <th>S No</th>
                        <th>Period Per Contribution</th>
                        <th>Periods</th>
                        <th>Intrest Rate On Investment</th>
                        <th>Value of intrest</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php 
                     $count = 1;
                     foreach($invest_planner as $planner): ?>
                        <tr>
                           <td><?= $count++ ?></td>
                           <td><?= $planner->per_period_contribution ?></td>
                           <td><?= $planner->periods ?></td>
                           <td><?= $planner->intrest_rate_on_investment ?></td>
                           <td><?= $planner->value_of_investment ?></td>
                        </tr>

                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <div id="styleSelector"></div>
      
         
          
            <script>
               $(document).ready(function(){
               var i=1;
               $("#add_row").click(function(){b=i-1;
               $('#addr'+i).html($('#addr'+b).html()).find('td:first-child').html(i+1);
               $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
               i++; 
               });
               $("#delete_row").click(function(){
               if(i>1){
               $("#addr"+(i-1)).html('');
               i--;
               }
               calc();
               });
               
               $('#tab_logic tbody').on('keyup change',function(){
               calc();
               });
               $('#tax').on('keyup change',function(){
               calc_total();
               });
               
               
               });
               
               function calc()
               {
               $('#tab_logic tbody tr').each(function(i, element) {
               var html = $(this).html();
               if(html!='')
               {
               var qty = $(this).find('.qty').val();
               var price = $(this).find('.price').val();
               $(this).find('.total').val(qty*price);
               
               calc_total();
               }
               });
               }
               
               function calc_total()
               {
               total=0;
               $('.total').each(function() {
               total += parseInt($(this).val());
               });
               $('#sub_total').val(total.toFixed(2));
               tax_sum=(total/100)*$('#tax1').val();
               $('#tax_amount').val(tax_sum.toFixed(2));
               $('#total_amount').val((tax_sum+total).toFixed(2));
               }
            </script>
         
      </div>
   </div>
</div>