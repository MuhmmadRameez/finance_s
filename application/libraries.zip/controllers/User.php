<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'vendor/autoload.php'; // Loads the library

use Twilio\Rest\Client;
class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$this->load->library('form_validation');
	}

	function index()
	{
		$this->load->view('user/signup');
	}

	public function insert()
	{
		
			
			$contact =  $this->input->post('phone');
			$email = 	$this->input->post('email');
			$data = array(
				'first_name'	=>	 $this->input->post('first_name'),
				'last_name'		=>	$this->input->post('last_name'),
				'email'					=>	$email,
				'phone'				  =>	$contact,
				'password'			   => md5($this->input->post('password')),	
				'id'				   =>$_SERVER['REMOTE_ADDR'],
				'created_at'		   =>  date("Y-m-d H:i:s"),
				'account_creation_date'=>date('Y-m-d'),
			);
			
		
			$this->User_model->insert_api($data);
		
			/*die($this->db->last_query());*/
			$id = $this->db->insert_id();
			$query = $this->send_sms($id);	
			$email = $this->send_otp_email($email);
			$array = array(
				'success'		=>	true,
			); 
		echo json_encode($array);
	}

	public function send_sms($user_id)
	{
			 $fourRandomDigit = rand(1000,9999);
			$sid = "AC7a534b6d3c715585fbbd895edad703c4"; // Your Account SID from www.twilio.com/console
			$token = "b6ed5b508700914ea1b2aba0ffab89cf"; // Your Auth Token from www.twilio.com/console

			$client = new Twilio\Rest\Client($sid, $token);
			$message = $client->messages->create(
			  '+923312191682', // Text this number
			  [
			    'from' => '+18289444389', // From a valid Twilio number
			    'body' => $fourRandomDigit
			  ]
			);
			$array = array(
				'verification_code'=>$fourRandomDigit,
			);
			$this->db->where('id',$user_id);
			/*$this->db->update('fs_signup',$array);*/
			redirect('User/account_verify/'.$user_id);
			/*print $message->sid;	*/		
	}

	public function send_otp_email($email)
	{
		
		$config = array(
		  		'protocol' => 'smtp',
		  		'smtp_host' => 'ssl://smtp.googlemail.com',
		  		'smtp_port' => 465,
		  		'smtp_user' => 'muhammadrameez135@gmail.com', // change it to yours
		  		'smtp_pass' => '03312191682', // change it to yours
		  		'mailtype' => 'html',
		  		'charset' => 'iso-8859-1',
		  		'wordwrap' => TRUE
			);
 
			$message = 	"
						<html>
						<head>
							<title>Verification Code</title>
						</head>
						<body>
							<h2>Thank you for Registering.</h2>
							<p>Your Account:</p>
							<p>Email: ".$email."</p>
							<p>Please click the link below to activate your account.</p>
						</body>
						</html>
						";
 
		    $this->load->library('email', $config);
		    $this->email->set_newline("\r\n");
		    $this->email->from($config['smtp_user']);
		    $this->email->to("rameezyousuf135@gmail.com");
		    $this->email->subject('Signup Verification Email');
		    $this->email->message($message);
			$sending_email = $this->email->send();
			if ($sending_email) 
			{
				echo "Email sent";exit();
			}
		    //sending email
		    if($this->email->send()){
		    	$this->session->set_flashdata('message','Activation code sent to email');
		    }
		    else{
		    	$this->session->set_flashdata('message', $this->email->print_debugger());
 
		    }
	}



	public function view_request()
	{
		$this->load->view('layout/header');
		$this->load->view('layout/nav');
		$this->load->view('user/view_user_request');
		$this->load->view('layout/footer');
	}

	public function account_verify($id)
	{
		$data['id']=$id;
		$this->load->view('user/account_verify',$data);

	}

	public function welcome_window($id)
	{
		$data['record']=$this->User_model->get_info($id);
		$this->load->view('user/welcome_message',$data);
	}

	function number_verification()
 	{
  	$id = $this->input->post('id');
  	$code = $this->input->post('code');
   $this->User_model->update_api();
/*   $this->after_verification_message($id);*/
   $array = array(
    'success'  => true
   );
  	$this->after_verification_message($id);
  }

public function after_verification_message($user_id)
	{
			$sid = "AC7a534b6d3c715585fbbd895edad703c4"; // Your Account SID from www.twilio.com/console
			$token = "b6ed5b508700914ea1b2aba0ffab89cf"; // Your Auth Token from www.twilio.com/console
			$client = new Twilio\Rest\Client($sid, $token);
			$this->db->where('id',$user_id);
			$query = $this->db->get("fs_signup")->row_array();
			$message = $client->messages->create(
			  '+923312191682', // Text this number
			  [
			    'from' => '+18289444389', // From a valid Twilio number
			    'body' => ' Dear Mr '.$query['first_name'].' your demo account activated from '.$query['account_creation_date'].' for 10 days',
			  ]
			);	
	}

	
	
}


?>