<?php 
	class User_profile extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('Basic_profile_model');
		}
		public function index()
		{
			$this->load->view('layout/header');
			$this->load->view('layout/nav');
			$this->load->view('user_profile/basic_profile');
			$this->load->view('layout/footer');
		}

	public function insert_basic()
	{
		/*print_r($_POST);exit();*/
			$contact =  $this->input->post('phone');
			$email = 	$this->input->post('email');
			$password = md5($this->input->post('password'));
			$data = array(
				'user_id'		   =>$_SESSION['id'],
				'first_name'	   =>$this->input->post('name'),
				'last_name'		   =>$this->input->post('lastname'),
				'dob'			   =>$this->input->post('dob'),
				'adress'		   =>$this->input->post('adress'),
				'country'		   =>$this->input->post('country'),
				'province'		   =>$this->input->post('province'),
				'city'		   	   =>$this->input->post('city'),
				'language'		   =>$this->input->post('language'),
				'gender'		   =>$this->input->post('gender'),
				'age'			   =>$this->input->post('age'),
				'martial_status'   =>$this->input->post('martial'),
				'created_at'	   =>date("Y-m-d H:i:s"),

			);
			$basic_profile = $this->Basic_profile_model->basic_profile($data);
			if ($basic_profile>0) 
			{
				$this->financial_income();
			}
			/*$id = $this->db->insert_id();
			$array = array(
				'success'		=>	true,
			); */
		
	}


	public function financial_income()
	{
		
			$data = array(
				'user_id'		   			=>$_SESSION['id'],
				'salary_income'	   			=>$this->input->post('salary_income'),
				'rental_income'		  		=>$this->input->post('rental_income'),
				'commision_income'			=>$this->input->post('commision_income'),
				'other_income'		   		=>$this->input->post('other_income'),
				'dividends'		   			=>$this->input->post('dividends'),
				'created_at'	   			=>date("Y-m-d H:i:s"),

			);
			$this->Basic_profile_model->financial_income($data);
	}

	public function save_record()
	{
		$this->insert_basic();
		$this->financial_income();
	}

	}
?>