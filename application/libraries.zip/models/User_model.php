<?php
class User_model extends CI_Model
{
	/*function fetch_all()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('tbl_sample');
	}*/

	function insert_api($data)
	{
		$this->db->insert('fs_signup', $data);

	}

	function fetch_single_user()
	{
		$query = $this->db->get('fs_signup');
		return $query->result();
	}

	function update_api()
	{
		$id   =$this->input->post('id');
		$verification_code =$this->input->post('code');
		$array = array(
			'is_approved'=>1,
		);
		$this->db->where('id', $id);
		$this->db->where('verification_code',$verification_code);
		$this->db->update('fs_signup',$array);
die($this->db->last_query());		
		if ($this->db->affected_rows()>0) 
		{
			return redirect('User/account_verify',$id);

		}
	}
	/*user info fetch after verification required id*/
	public function get_info($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('fs_signup')->row_array();
		

	}

	function delete_single_user($user_id)
	{
		$this->db->where('id', $user_id);
		$this->db->delete('tbl_sample');
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}

?>