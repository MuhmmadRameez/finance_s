<?php 
$config = Array(
      'protocol' => 'smtp',
      'smtp_host' => 'ssl://smtp.googlemail.com',
      'smtp_port' => 465,
      'smtp_user' => '<test-account-name>@gmail.com',
      'smtp_pass' => '<test-account-password>',
    );
?>
