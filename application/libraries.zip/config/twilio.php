<?php 
 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
$config['mode'] = 'sandbox';
 
/**
* Account SID
**/
$config['account_sid'] = 'SK2c76953e2e5bfee2dbff07ef3d9274b4';
 
/**
* Auth Token
**/
$config['auth_token'] = '400Xj9dMJUhVZtH5N1DLlJ04NA6f3fW7';
 
/**
* API Version
**/
$config['api_version'] = '2010-04-01';
 
/**
* Twilio Phone Number
**/
$config['number'] = '+18289444389';
 
/* End of file twilio.php */
?>