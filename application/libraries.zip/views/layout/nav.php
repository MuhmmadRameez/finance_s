<div class="pcoded-main-container">
               <div class="pcoded-wrapper">
                  <nav class="pcoded-navbar">
                     <div class="nav-list">
                        <div class="pcoded-inner-navbar main-menu">
                           <div class="pcoded-navigation-label">Navigation</div>
                           <ul class="pcoded-item pcoded-left-item">
                              <li class="pcoded-hasmenu active pcoded-trigger">
                                 <a href="javascript:void(0)" class="waves-effect waves-dark">
                                 <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                                 <span class="pcoded-mtext">Dashboard</span>
                                 </a>
                           </ul>
                           <ul class="pcoded-item pcoded-left-item">
                           
                              <li class=" ">
                                 <a href="#" class="waves-effect waves-dark">
                                 <span class="pcoded-micon">
                                 <i class="feather icon-edit-1"></i>
                                 </span>
                                 <span class="pcoded-mtext">Financial goals</span>
                                 </a>
                              </li>

                                 <li class=" ">
                                 <a href="#" class="waves-effect waves-dark">
                                 <span class="pcoded-micon">
                                 <i class="feather icon-edit-1"></i>
                                 </span>
                                 <span class="pcoded-mtext">Budgets</span>
                                 </a>
                              </li>

                                 <li class=" ">
                                 <a href="#" class="waves-effect waves-dark">
                                 <span class="pcoded-micon">
                                 <i class="feather icon-edit-1"></i>
                                 </span>
                                 <span class="pcoded-mtext">Financial Planner</span>
                                 </a>
                              </li>

                                 <li class=" ">
                                 <a href="#" class="waves-effect waves-dark">
                                 <span class="pcoded-micon">
                                 <i class="feather icon-edit-1"></i>
                                 </span>
                                 <span class="pcoded-mtext">Calculator</span>
                                 </a>
                              </li>

                                 <li class=" ">
                                 <a href="#" class="waves-effect waves-dark">
                                 <span class="pcoded-micon">
                                 <i class="feather icon-edit-1"></i>
                                 </span>
                                 <span class="pcoded-mtext">Setting</span>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </nav>