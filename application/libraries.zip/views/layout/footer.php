   <!--[if lt IE 10]>
      <div class="ie-warning">
         <h1>Warning!!</h1>
         <p>You are using an outdated version of Internet Explorer, please upgrade
            <br/>to any of the following web browsers to access this website.
         </p>
         <div class="iew-container">
            <ul class="iew-download">
               <li>
                  <a href="http://www.google.com/chrome/">
                     <img src="../files/assets/images/browser/chrome.png" alt="Chrome">
                     <div>Chrome</div>
                  </a>
               </li>
               <li>
                  <a href="https://www.mozilla.org/en-US/firefox/new/">
                     <img src="../files/assets/images/browser/firefox.png" alt="Firefox">
                     <div>Firefox</div>
                  </a>
               </li>
               <li>
                  <a href="http://www.opera.com">
                     <img src="../files/assets/images/browser/opera.png" alt="Opera">
                     <div>Opera</div>
                  </a>
               </li>
               <li>
                  <a href="https://www.apple.com/safari/">
                     <img src="../files/assets/images/browser/safari.png" alt="Safari">
                     <div>Safari</div>
                  </a>
               </li>
               <li>
                  <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                     <img src="../files/assets/images/browser/ie.png" alt="">
                     <div>IE (9 & above)</div>
                  </a>
               </li>
            </ul>
         </div>
         <p>Sorry for the inconvenience!</p>
      </div>
      <![endif]-->
      <script data-cfasync="false" src="<?= base_url() ?>/assets/js/email-decode.min.js"></script><script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/jquery.min.js"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/jquery-ui.min.js"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/popper.min.js"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/bootstrap.min.js"></script>
      <script src="<?= base_url() ?>/assets/js/waves.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/jquery. <script src="js/jquery.cookie.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>.js"></script>
      <script src="<?= base_url() ?>/assets/js/jquery.flot.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/jquery.flot.categories.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/curvedlines.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/jquery.flot.tooltip.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/chartist.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/amcharts.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/serial.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/light.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/pcoded.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/vertical-layout.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/custom-dashboard.min.js"></script>
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?= base_url() ?>/assets/js/script.min.js"></script>
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>

       <script src="<?= base_url() ?>/assets/js/jszip.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/pdfmake.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/vfs_fonts.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/buttons.print.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/buttons.html5.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/datatables.bootstrap4.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/datatables.responsive.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/responsive.bootstrap4.min.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
      <script src="<?= base_url() ?>assets/js/data-table-custom.js" type="630c93344707674ca80c0e8e-text/javascript"></script>
 <script src="<?= base_url() ?>assets/js/form-wizard.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>
<script src="<?= base_url() ?>/assets/js/rocket-loader.min.js" data-cf-settings="d2d1d6e2f87cbebdf4013b26-|49" defer=""></script>


 <script src="<?= base_url() ?>assets/js/jquery.cookie.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>
  <script src="<?= base_url() ?>/assets/js/jquery.steps.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>

 <script src="<?= base_url() ?>/assets/js/moment.min.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>
      <script src="<?= base_url() ?>/assets/js/jquery.mcustomscrollbar.concat.min.js" type="ce2668daaac54a74e9f6cdff-text/javascript"></script>
       <script type="ce2668daaac54a74e9f6cdff-text/javascript" 
       src="<?= base_url() ?>/assets/js/jquery.slimscroll.js"></script>
        <script src="<?= base_url() ?>/assets/js/rocket-loader.min.js" data-cf-settings="ce2668daaac54a74e9f6cdff-|49" defer=""></script> 
      <script type="d2d1d6e2f87cbebdf4013b26-text/javascript">


         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         
         gtag('config', 'UA-23581568-13');
      </script>
    
   </body>
   <!-- Mirrored from colorlib.com/polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Dec 2019 16:08:25 GMT -->
</html>