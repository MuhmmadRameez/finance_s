<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_profile_api_links extends CI_Controller {

 function index()
 {
  $this->load->view('api_view');
 }
/*Account verification start after signup*/ 
 function action()
 {

/*basic profile insertion*/
   if($data_action == "insert_basic")
   {
    $api_url = "http://finance.xavishop.com/index.php/User_profile/insert_basic";
    /*$api_url = "localhost/finance_system/index.php/User_profile/insert_basic"*/

    /*$api_url = "http://finance.xavishop.com/index.php/User/insert";*/
   

    $form_data = array(

    		/*'user_id'      =>$_SESSION['id'];*/
        'first_name'     =>$this->input->post('name'),
        'last_name'      =>$this->input->post('lastname'),
        'dob'        =>$this->input->post('dob'),
        'adress'       =>$this->input->post('adress'),
        'country'      =>$this->input->post('country'),
        'province'       =>$this->input->post('province'),
        'city'           =>$this->input->post('city'),
        'language'       =>$this->input->post('language'),
        'gender'       =>$this->input->post('gender'),
        'age'        =>$this->input->post('age'),
        'image'        =>$picture,
        'martial_status'   =>$this->input->post('martial'),
        'created_at'     =>date("Y-m-d H:i:s"),
    );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;


   }
/*basic profile insertion end*/


 if($data_action == "financial_income")
   {
    /*$api_url = "localhost/finance_system/index.php/User_profile/financial_income";*/
    $api_url = "http://finance.xavishop.com/index.php/User_profile/financial_income";

    /*$api_url = "http://finance.xavishop.com/index.php/User/insert";*/
   
/*financial income start*/
    $form_data = array(
        'user_id'                =>$this->input->post('id'),
        'salary_income'         =>$this->input->post('salary_income'),
        'rental_income'         =>$this->input->post('rental_income'),
        'commision_income'      =>$this->input->post('commision_income'),
        'other_income'          =>$this->input->post('other_income'),
        'dividends'           =>$this->input->post('dividends'),
        'created_at'          =>date("Y-m-d H:i:s"),
    );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;


   }

/*financial income end*/
  }

/*debits*/

 if($data_action == "debits")
   {
    $api_url = "http://finance.xavishop.com/index.php/User_profile/debits"
    /*$api_url = "localhost/finance_system/index.php/User_profile/debits */
   
/*financial income start*/
    $form_data = array(
        'user_id'      =>$this->input->post('id'),
        'accounts_payable'        =>$this->input->post('account'),
        'credit_card_debit'       =>$this->input->post('credit_card'),
        'loan_auto_finance'     =>$this->input->post('loan'),
        'student_loan'          =>$this->input->post('student_loan'),
        'money_owed_to_others'    =>$this->input->post('other'),
        'auto_loan'           =>$this->input->post('auto_loan'),
        'consumer_loan'       =>$this->input->post('consumer_loan'),
        'real_estate'       =>$this->input->post('real_estate'),
        'unpaid_tax'        =>$this->input->post('taxes'),
        'other_libalities'      =>$this->input->post('liabilities'),
        'creted_at'           =>date("Y-m-d H:i:s"),
    );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;


   }
/*debits end*/

 }
 
}

?>