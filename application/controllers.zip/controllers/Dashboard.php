<?php 
class Dashboard extends CI_Controller
{
	public function __construct()
		{
			parent::__construct();
			if ($_SESSION['id']=="") 
			{
				return redirect('Login/');
			}
		}
	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('layout/nav');
		$this->load->view('layout/content');
		$this->load->view('layout/footer');
	}
}
?>