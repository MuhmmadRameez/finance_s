<?php 
	class Budget extends CI_Controller
	{
		public function index()
		{
			$this->load->view('layout/header');
			$this->load->view('layout/nav');
			$this->load->view('budget/budget');
			$this->load->view('layout/footer');
		}
	}
?>