<?php
$item = $plaid->items->get("itm_1234");
	class Plaid_test extends CI_Controller
	{
		public function index()
		{
			print_r($items);
		}
	}
 ?>