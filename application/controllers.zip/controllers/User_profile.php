<?php 
	class User_profile extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('Basic_profile_model');
		}
		public function index()
		{
			$this->load->view('layout/header');
			$this->load->view('layout/nav');
			$this->load->view('user_profile/basic_profile');
			$this->load->view('layout/footer');
		}

	public function insert_basic()
	{
		if(!empty($_FILES['profile_image']['name'])){
			$config['upload_path'] = 'assets/user_images/';
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['file_name'] = $_FILES['profile_image']['name'];

			//Load upload library and initialize configuration
			$this->load->library('upload',$config);
			$this->upload->initialize($config);

			if($this->upload->do_upload('profile_image')){
				$uploadData = $this->upload->data();
				$picture = $uploadData['file_name'];
			}else{
				$picture = '';
			}
		}else{
			$picture = '';
		}
			
			$data = array(
				'user_id'		   =>$this->input->post('id'),
				'first_name'	   =>$this->input->post('name'),
				'last_name'		   =>$this->input->post('last_name'),
				'dob'			   =>$this->input->post('dob'),
				'adress'		   =>$this->input->post('adress'),
				'country'		   =>$this->input->post('country'),
				'province'		   =>$this->input->post('province'),
				'city'		   	   =>$this->input->post('city'),
				'language'		   =>$this->input->post('language'),
				'gender'		   =>$this->input->post('gender'),
				'age'			   =>$this->input->post('age'),
				'image'			   =>$picture,
				'martial_status'   =>$this->input->post('martial'),
				'created_at'	   =>date("Y-m-d H:i:s"),

			);
			$basic_profile = $this->Basic_profile_model->basic_profile($data);
			
			if ($basic_profile>0) 
			{
				$this->financial_income();
				$this->debits();
			}
			/*$id = $this->db->insert_id();
			$array = array(
				'success'		=>	true,
			); */
		
	}

		public function financial_income()
		{
		
			$data = array(
				'user_id'		   =>$this->input->post('id'),
				'salary_income'	   			=>$this->input->post('salary_income'),
				'rental_income'		  		=>$this->input->post('rental_income'),
				'commision_income'			=>$this->input->post('commision_income'),
				'other_income'		   		=>$this->input->post('other_income'),
				'dividends'		   			=>$this->input->post('dividends'),
				'created_at'	   			=>date("Y-m-d H:i:s"),

			);
			$this->Basic_profile_model->financial_income($data);
	}

	public function debits()
	{
		
			$data = array(
				'user_id'		   			=>$this->input->post('id'),
				'accounts_payable'	   		=>$this->input->post('account'),
				'credit_card_debit'		  	=>$this->input->post('credit_card'),
				'loan_auto_finance'			=>$this->input->post('loan'),
				'student_loan'		   		=>$this->input->post('student_loan'),
				'money_owed_to_others'		=>$this->input->post('other'),
				'auto_loan'				    =>$this->input->post('auto_loan'),
				'consumer_loan'				=>$this->input->post('consumer_loan'),
				'real_estate'				=>$this->input->post('real_estate'),
				'unpaid_tax'				=>$this->input->post('taxes'),
				'other_libalities'			=>$this->input->post('liabilities'),
				'creted_at'	   				=>date("Y-m-d H:i:s"),

			);
			$this->Basic_profile_model->debits($data);
	}

	public function save_record()
	{
		$this->insert_basic();
		$this->financial_income();
	}

	}
?>